$(':radio').change(function () {
    console.log('New star rating: ' + this.value);
});