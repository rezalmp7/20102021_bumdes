

                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © Bumdes.
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        
        <!-- init js -->
        <script src="<?php echo base_url(); ?>assets/admin/assets/js/pages/form-editor.init.js"></script>

        <!-- color picker js -->
        <script src="<?php echo base_url(); ?>assets/admin/assets/libs/@simonwep/pickr/pickr.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/assets/libs/@simonwep/pickr/pickr.es5.min.js"></script>

        <!-- datepicker js -->
        <script src="<?php echo base_url(); ?>assets/admin/assets/libs/flatpickr/flatpickr.min.js"></script>

        <!-- init js -->
        <script src="<?php echo base_url(); ?>assets/admin/assets/js/pages/form-advanced.init.js"></script>
        
        <!-- END layout-wrapper -->
        <script src="<?php echo base_url(); ?>assets/admin/assets/js/app.js"></script>
        

        <script>
        feather.replace()
        </script>
    </body>

</html>